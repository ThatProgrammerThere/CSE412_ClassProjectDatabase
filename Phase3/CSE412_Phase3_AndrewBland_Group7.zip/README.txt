Phase 1: ER Diagram, Forms, Queries & Reports
Phase 2: Schema, ER Diagram, Constraints

